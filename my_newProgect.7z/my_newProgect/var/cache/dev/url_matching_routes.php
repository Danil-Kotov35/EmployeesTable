<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/getEmployees' => [[['_route' => 'employeeTable', '_controller' => 'App\\Controller\\EmployeeTableController::employeeTable'], null, null, null, false, false, null]],
        '/TableDisplay' => [[['_route' => 'setEmployee', '_controller' => 'App\\Controller\\ListActionController::newEmployeesAction'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'redirectHomePage', '_controller' => 'App\\Controller\\HomeController::redirectHome'], null, null, null, false, false, null]],
        '/home' => [[['_route' => 'homePage', '_controller' => 'App\\Controller\\HomeController::home'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
                .'|/updatelist/([^/]++)(*:62)'
                .'|/deletelist/([^/]++)(*:89)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        62 => [[['_route' => 'updateAction', '_controller' => 'App\\Controller\\ListActionController::UpdateList'], ['id'], null, null, false, true, null]],
        89 => [
            [['_route' => 'deleteAction', '_controller' => 'App\\Controller\\ListActionController::deleteList'], ['id'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
