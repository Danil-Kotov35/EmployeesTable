<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* /update.html.twig */
class __TwigTemplate_3ceab79f9e676727346e712cf0950c5a extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "/update.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "/update.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 2
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 3
        echo "    <style>
        #simpleform {
            width:600px;
            border:2px solid grey;
            padding:14px;
            margin: 0 auto;
        }
        #simpleform label {
            font-size:14px;
            float:left;
            width:300px;
            text-align:right;
            display:block;
        }
        #simpleform span {
            font-size:11px;
            color:grey;
            width:100px;
            text-align:right;
            display:block;
        }
        #simpleform input {
            border:1px solid grey;
            font-size:14px;
            color:blue;
            height:24px;
            width:250px;
            margin: 0 0 10px 10px;
        }
        #simpleform textarea {
            border:1px solid grey;
            font-size:14px;
            color:blue;
            height:120px;
            width:250px;
            margin: 0 0 20px 10px;
        }
        #simpleform select {
            margin: 0 0 20px 10px;
        }
        #simpleform button {
            clear:both;
            margin-left:250px;
            background: grey;
            color:#FFFFFF;
            border:solid 1px #666666;
            font-size:16px;
        }
        h3{
            text-align: center;
        }

    </style>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 57
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 58
        echo "    <h3>Изменить данные Сотрудника:</h3>
    <div id = \"simpleform\">
        ";
        // line 60
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 60, $this->source); })()), 'form_start');
        echo "
        ";
        // line 61
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 61, $this->source); })()), 'widget');
        echo "
        ";
        // line 62
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 62, $this->source); })()), 'form_end');
        echo "
    </div>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    public function getTemplateName()
    {
        return "/update.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  139 => 62,  135 => 61,  131 => 60,  127 => 58,  120 => 57,  60 => 3,  53 => 2,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block stylesheets %}
    <style>
        #simpleform {
            width:600px;
            border:2px solid grey;
            padding:14px;
            margin: 0 auto;
        }
        #simpleform label {
            font-size:14px;
            float:left;
            width:300px;
            text-align:right;
            display:block;
        }
        #simpleform span {
            font-size:11px;
            color:grey;
            width:100px;
            text-align:right;
            display:block;
        }
        #simpleform input {
            border:1px solid grey;
            font-size:14px;
            color:blue;
            height:24px;
            width:250px;
            margin: 0 0 10px 10px;
        }
        #simpleform textarea {
            border:1px solid grey;
            font-size:14px;
            color:blue;
            height:120px;
            width:250px;
            margin: 0 0 20px 10px;
        }
        #simpleform select {
            margin: 0 0 20px 10px;
        }
        #simpleform button {
            clear:both;
            margin-left:250px;
            background: grey;
            color:#FFFFFF;
            border:solid 1px #666666;
            font-size:16px;
        }
        h3{
            text-align: center;
        }

    </style>
{% endblock %}
{% block body %}
    <h3>Изменить данные Сотрудника:</h3>
    <div id = \"simpleform\">
        {{ form_start(form) }}
        {{ form_widget(form) }}
        {{ form_end(form) }}
    </div>
{% endblock %}", "/update.html.twig", "C:\\Users\\Даниил\\my_newProgect\\templates\\update.html.twig");
    }
}
