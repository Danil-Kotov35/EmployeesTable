<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* /display.html.twig */
class __TwigTemplate_e273ae9fb617040b77582f8c7479722e extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "/display.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "/display.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 2
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 3
        echo "    <style>
        .table { border-collapse: collapse; }
        .table th, td {
            border-bottom: 1px solid #ddd;
            width: 250px;
            text-align: left;
            align: left;
        }
        th{
            cursor: pointer;
            user-select:none;
        }

    </style>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 18
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 19
        echo "    <h2>Наши сотрудники</h2>
    <table id=\"table\" class = \"table\">
        <thead>
            <tr>
                <th data-type = 'string'>Имя</th>
                <th data-type = 'string'>Должность</th>
                <th data-type = 'number'>Зарплата</th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            ";
        // line 31
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 31, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["x"]) {
            // line 32
            echo "                <tr>
                    <td>";
            // line 33
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["x"], "Name", [], "any", false, false, false, 33), "html", null, true);
            echo "</td>
                    <td>";
            // line 34
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["x"], "JobTitle", [], "any", false, false, false, 34), "html", null, true);
            echo "</td>
                    <td>";
            // line 35
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["x"], "Salary", [], "any", false, false, false, 35), "html", null, true);
            echo "</td>
                    <td><a href = \"";
            // line 36
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("updateAction", ["id" => twig_get_attribute($this->env, $this->source, $context["x"], "Id", [], "any", false, false, false, 36)]), "html", null, true);
            echo "\">Изменить</a></td>
                    <td><a href = \"";
            // line 37
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("deleteAction", ["id" => twig_get_attribute($this->env, $this->source, $context["x"], "Id", [], "any", false, false, false, 37)]), "html", null, true);
            echo "\">Удалить</a></td>
                </tr>

            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['x'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 41
        echo "        </tbody>
    </table>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 44
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 45
        echo "
    <script>
        table.onclick = function (e){
            if (e.target.tagName != 'TH') return
            let th = e.target
            sortTable(th.cellIndex,th.dataset.type)
        }

        function sortTable(colNum,type){
            let tbody = table.querySelector('tbody')
            let rowsArray = Array.from(tbody.rows)
            let compare;
            switch (type){
                case 'number':
                    compare = function (rowA,rowB){
                        return rowA.cells[colNum].innerHTML - rowB.cells[colNum].innerHTML
                    }
                    break;
                case 'string':
                    compare = function (rowA,rowB){
                        return rowA.cells[colNum].innerHTML > rowB.cells[colNum].innerHTML ? 1 : -1;
                    }
                    break;
            }
            rowsArray.sort(compare);
            tbody.append(...rowsArray);
        }
    </script>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    public function getTemplateName()
    {
        return "/display.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  152 => 45,  145 => 44,  136 => 41,  126 => 37,  122 => 36,  118 => 35,  114 => 34,  110 => 33,  107 => 32,  103 => 31,  89 => 19,  82 => 18,  61 => 3,  54 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block stylesheets %}
    <style>
        .table { border-collapse: collapse; }
        .table th, td {
            border-bottom: 1px solid #ddd;
            width: 250px;
            text-align: left;
            align: left;
        }
        th{
            cursor: pointer;
            user-select:none;
        }

    </style>
{% endblock %}
{% block body %}
    <h2>Наши сотрудники</h2>
    <table id=\"table\" class = \"table\">
        <thead>
            <tr>
                <th data-type = 'string'>Имя</th>
                <th data-type = 'string'>Должность</th>
                <th data-type = 'number'>Зарплата</th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            {% for x in data %}
                <tr>
                    <td>{{ x.Name }}</td>
                    <td>{{ x.JobTitle }}</td>
                    <td>{{ x.Salary }}</td>
                    <td><a href = \"{{ path('updateAction', { 'id' : x.Id }) }}\">Изменить</a></td>
                    <td><a href = \"{{ path('deleteAction', { 'id' : x.Id }) }}\">Удалить</a></td>
                </tr>

            {% endfor %}
        </tbody>
    </table>
{% endblock %}
{% block javascripts %}

    <script>
        table.onclick = function (e){
            if (e.target.tagName != 'TH') return
            let th = e.target
            sortTable(th.cellIndex,th.dataset.type)
        }

        function sortTable(colNum,type){
            let tbody = table.querySelector('tbody')
            let rowsArray = Array.from(tbody.rows)
            let compare;
            switch (type){
                case 'number':
                    compare = function (rowA,rowB){
                        return rowA.cells[colNum].innerHTML - rowB.cells[colNum].innerHTML
                    }
                    break;
                case 'string':
                    compare = function (rowA,rowB){
                        return rowA.cells[colNum].innerHTML > rowB.cells[colNum].innerHTML ? 1 : -1;
                    }
                    break;
            }
            rowsArray.sort(compare);
            tbody.append(...rowsArray);
        }
    </script>
{% endblock %}

", "/display.html.twig", "C:\\Users\\Даниил\\my_newProgect\\templates\\display.html.twig");
    }
}
